import java.io.*;
import java.util.*;

public class Game {
    private static int numPlayers;
    private static ArrayList<Scores> totals =  new ArrayList<>();
    private static int numTribes;
    private static ArrayList<Tribe> tribes = new ArrayList<>();
    private static int day = 0;
    private static ArrayList<Player> players = new ArrayList<>();
    private static Random r = new Random();
    private static Tribe losingTribe;
    private static HashMap<Integer, Player> votedOut = new HashMap<>();
    private static ArrayList<Player> eliminated = new ArrayList<>();
    private static ArrayList<Player> jury = new ArrayList<>();
    private int numImmune = 0;
    private int lostTribe = 0;
    private HashMap<Integer,String> indChallenges = new HashMap<>();
    private HashMap<String, String> indChalDescriptions = new HashMap<>();
    private HashMap<Integer,String> teamChallenges = new HashMap<>();
    private HashMap<String, String> teamChalDescriptions = new HashMap<>();
    private Player soleSurvivor = new Player();
    private Player secondPlace = new Player();
    private HashMap<Player, Integer> immunityWins = new HashMap<>();
    private HashMap<Player, Player> finalTribalVotes = new HashMap<>();
    private HashMap<Player,Player> tribalCouncilVotes = new HashMap<>();


    public static void main(String[] args) throws IOException {
        Scanner throwAway = new Scanner(System.in);
        Game a = new Game();
        a.gameSetUp();
        while(players.size()>10){
            if(day%12==0 && day!=0){
                a.tribeSwap();
            }
            a.tribalImmunityChallenge();
            a.tribalCouncil(losingTribe);
            for(int i = 0; i<numTribes;i++){
                System.out.println(tribes.get(i).toString());
            }
        }
        a.merge();
        while(players.size()>2) {
            a.individualImmunityChallenge();
            a.tribalCouncil(losingTribe);
            System.out.println(tribes.get(0).toString());
        }
        System.out.println("Type 1 and Press Enter To See The Final Results");
        throwAway.next();
        System.out.println();
        a.finalTribal();
        System.out.println("Type 1 and Press Enter To See The Statistics");
        throwAway.next();
        a.finalTribalVotes();
        a.placements();
        a.immunityWins();
        a.totals();
    }

    public void gameSetUp() throws IOException {
        FileInputStream team = new FileInputStream("teamChallenges.txt");
        Scanner tchals = new Scanner(team);
        int o = 0;
        while(tchals.hasNextLine()){
            String tchalllengeName= tchals.nextLine();
            teamChallenges.put(o,tchalllengeName);
            String descript = tchals.nextLine();
            Scanner parse = new Scanner(descript);
            parse.useDelimiter("");
            String parsedD = "";
            int letters = 0;
            while(parse.hasNext()){
                String nextLet = parse.next();
                parsedD = parsedD + nextLet;
                letters++;
                if(letters>=125 && nextLet.equals(" ")){
                    parsedD = parsedD + System.lineSeparator();
                    letters = 0;
                }
            }
            teamChalDescriptions.put(tchalllengeName,parsedD);
            o++;
        }
        FileInputStream ind = new FileInputStream("indChallenges.txt");
        Scanner ichals = new Scanner(ind);
        int p = 0;
        while(ichals.hasNextLine()){
            String ichalllengeName= ichals.nextLine();
            indChallenges.put(p,ichalllengeName);
            String descript = ichals.nextLine();
            Scanner parse = new Scanner(descript);
            parse.useDelimiter("");
            String parsedD = "";
            int letters = 0;
            while(parse.hasNext()){
                String nextLet = parse.next();
                parsedD = parsedD + nextLet;
                letters++;
                if(letters>=125 && nextLet.equals(" ")){
                    parsedD = parsedD + System.lineSeparator();
                    letters = 0;
                }
            }
            indChalDescriptions.put(ichalllengeName,parsedD);
            p++;
        }
        Scanner sc = new Scanner(System.in);
        System.out.println("Jeff Probst: Welcome to Survivor!");
        System.out.println("Jeff Probst: How many players?");
        numPlayers = sc.nextInt();
        while(numPlayers != 16 && numPlayers != 18 && numPlayers != 20){
            System.out.println("Jeff Probst: Please enter 16, 18, or 20");
            numPlayers = sc.nextInt();
        }
        sc.nextLine();
        for(int i = 0; i<numPlayers;i++){
            System.out.println("Jeff Probst: What is the name of the next player?");
            String name = sc.nextLine();
            Player a = new Player(name,false,r.nextInt(2),0);
            players.add(a);
        }
        System.out.println("Jeff Probst: Here are your players: ");
        for(int i = 0;i<players.size();i++){
            System.out.print(players.get(i).getName() + ", ");
        }
        System.out.println();
        System.out.println("Jeff Probst: How many tribes?");
        numTribes = sc.nextInt();
        sc.nextLine();
        while(numTribes>4 || numTribes<1){
            System.out.println("Jeff Probst: Too many, try again");
            numTribes = sc.nextInt();
        }
        while(numPlayers%numTribes != 0){
            System.out.println("Jeff Probst: Tribes are not even, pick again");
            numTribes = sc.nextInt();
        }
        ArrayList<Player> playersCopy = new ArrayList<>();
        playersCopy.addAll(players);
        for(int i = 0; i<numTribes;i++){
            ArrayList<Player> tribeMems = new ArrayList<>();
            for(int j = 0; j<numPlayers/numTribes;j++){
                Player nextPlayer = playersCopy.get(r.nextInt(playersCopy.size()));
                while(tribeMems.contains(nextPlayer)){
                    nextPlayer = playersCopy.get(r.nextInt(playersCopy.size()));
                }
                tribeMems.add(nextPlayer);
                playersCopy.remove(nextPlayer);
            }
            int tribeNum = i+1;
            System.out.println("Name Tribe "+ tribeNum);
            Tribe a = new Tribe(sc.nextLine(),tribeMems, 0);
            tribes.add(a);
        }
        System.out.println(tribes.toString());
        team.close();
        ind.close();
    }

    public void merge(){
        Scanner sc = new Scanner(System.in);
        ArrayList<Player> mergeSet = new ArrayList<>();
        for(int i = 0; i<numTribes;i++){
            for(int j = 0; j<tribes.get(i).getTribePlayers().size();j++)
            mergeSet.add(tribes.get(i).getTribePlayers().get(j));
        }
        while(tribes.size()!=0){
            tribes.remove(0);
        }
        System.out.println("Jeff Probst: Everyone drop your buffs!");
        System.out.println("Jeff Probst: Congratulations, you are merged!");
        System.out.println("Jeff Probst: Please select a merge tribe name!");
        Tribe merge = new Tribe(sc.nextLine(),mergeSet,0);
        tribes.add(merge);
        numTribes=1;
        lostTribe=0;
    }

    public void individualImmunityChallenge(){
        String chalName = "";
        System.out.println("Jeff Probst: Welcome to the Day " + day + " Immunity Challenge");
        System.out.println("Jeff Probst: I'll take back immunity");
        System.out.println("Jeff Probst: Once again, individual immunity is back up for grabs");
        chalName= indChallenges.get(r.nextInt(indChallenges.size()));
        System.out.println("Jeff Probst: Today's challenge is called " + chalName);
        System.out.println("Jeff Probst: Here is the challenge description:");
        System.out.println(indChalDescriptions.get(chalName).toString());
                numImmune = r.nextInt(players.size());
        Player immune = tribes.get(0).getTribePlayers().get(numImmune);
        System.out.println("Jeff Probst: "+ immune + " wins immunity and is safe tonight at Tribal Council");
        tribes.get(0).getTribePlayers().get(numImmune).setImmune(true);
        tribes.get(0).getTribePlayers().get(numImmune).setScore(tribes.get(0).getTribePlayers().get(numImmune).getScore()+3);
        tribes.get(0).getTribePlayers().get(numImmune).setImmWins(tribes.get(0).getTribePlayers().get(numImmune).getImmWins()+1);
        immunityWins.put(tribes.get(0).getTribePlayers().get(numImmune),tribes.get(0).getTribePlayers().get(numImmune).getImmWins());
        System.out.println("Jeff Probst: For the rest of you, one of you will be sent home tonight and become the next member of the Jury");
        System.out.println("Jeff Probst: Head back to camp, I'll see you tonight");
        losingTribe = tribes.get(0);
        System.out.println();
        System.out.println("-------------------------");
        System.out.println();
    }

    public void tribalImmunityChallenge(){
        String chalName = "";
        System.out.println("Jeff Probst: Welcome to the Day " + day + " Immunity Challenge");
        for(int i =0;i<numTribes;i++){
            if(tribes.get(i)!=losingTribe && day>2){
                System.out.println("Jeff Probst: " + tribes.get(i).tribeName() + " take a look at the new " + losingTribe.tribeName() + " Tribe");
            }
        }
        System.out.println("Jeff Probst: Alright, I'll take back immunity");
        System.out.println("Jeff Probst: Once again, tribal immunity is back up for grabs");
        chalName = teamChallenges.get(r.nextInt(teamChallenges.size()));
        System.out.println("Jeff Probst: Today's challenge is called " + chalName);
        System.out.println("Jeff Probst: Here is a description of the challenge: ");
        System.out.println(teamChalDescriptions.get(chalName).toString());
        //this is where Jeff would describe said challenge, gonna just be random now
        lostTribe = r.nextInt(numTribes);
        losingTribe = tribes.get(lostTribe);
        for(int i =0; i<numTribes;i++){
            if(tribes.get(i)!=losingTribe){
                System.out.println("Jeff Probst: "+ tribes.get(i).tribeName()+ " wins immunity!");
            }
        }
        System.out.println("Jeff Probst: " + losingTribe.tribeName() + " I've got nothing for you but a date with me at tribal council");
        System.out.println("Jeff Probst: Where one of you will be sent home tonight and lose your flame");
        System.out.println("Jeff Probst: Head back to camp, I'll see you tonight");
        System.out.println();
        System.out.println("-------------------------");
        System.out.println();
    }

    public void tribalCouncil(Tribe losers){
        HashMap<Player, Integer> votes = new HashMap<>();
        ArrayList<Player> voteCnt = new ArrayList<>();
        int votesLeft = losers.getTribePlayers().size();
        int max = 0;
        System.out.println("Jeff Probst: Welcome back to tribe council, where fire represents your life in the game");
        if(players.size()>10){
            System.out.println("Jeff Probst: " + losers.getTribeName() + " tough loss out there");
        }
        if(jury.size()>0) {
            System.out.println("Jeff Probst: Here are the members of the Jury: " + jury.toString());
        }
        System.out.println("Jeff Probst: It's time to vote");
        System.out.println(losers.getTribePlayers().get(r.nextInt(losers.getTribePlayers().size())) + " start us off!");
        for(int i = 0; i<losers.getTribePlayers().size();i++){
            Player vote = losers.getTribePlayers().get(r.nextInt(losers.getTribePlayers().size()));
            while(vote.isImmune() || vote==losers.getTribePlayers().get(i)){
                vote = losers.getTribePlayers().get(r.nextInt(losers.getTribePlayers().size()));
            }
            voteCnt.add(vote);
            tribalCouncilVotes.put(losers.getTribePlayers().get(i),vote);
        }
        System.out.println("Jeff Probst: I'll read the votes");
        Player voteName;
        for(int i = 0; i< voteCnt.size();i++) {
            voteName  = voteCnt.get(i);
            System.out.println("One vote: " + voteName);
            votes.put(voteName,votes.getOrDefault(voteName,0)+1);
            System.out.println("Jeff Probst: That is " + votes.get(voteName) + " votes for " + voteName);
            if(votes.get(voteName)>max){
                max = votes.get(voteName);
            }
            if(votes.get(voteName)==max){
                votedOut.put(max,voteName);
            }
            votesLeft = votesLeft -1;
        }
        List<Player> listOfKeys= null;
        if(votes.containsValue(max)){
                listOfKeys = new ArrayList<>();
                for(Map.Entry<Player,Integer> entry : votes.entrySet()){
                    if(entry.getValue().equals(max)){
                        listOfKeys.add(entry.getKey());
                    }
                }
            }
        if(listOfKeys.size()!=1){
            System.out.println("Jeff Probst: There is a tie, we must revote!");
            System.out.println();
            System.out.println("Jeff Probst: Here is who voted for who: ");
            System.out.println(tribalCouncilVotes);
            System.out.println();
            tribalCouncilVotes.clear();
            votes.clear();
            voteCnt.clear();
            for(int i = 0; i<losers.getTribePlayers().size();i++){
                if(listOfKeys.contains(losers.getTribePlayers().get(i))){
                    continue;
                }
                Player vote = listOfKeys.get(r.nextInt(listOfKeys.size()));
                while(vote.isImmune() || vote==losers.getTribePlayers().get(i)){
                    vote = listOfKeys.get(r.nextInt(listOfKeys.size()));
                }
                voteCnt.add(vote);
                if(!listOfKeys.contains(losers.getTribePlayers().get(i))){
                    tribalCouncilVotes.put(losers.getTribePlayers().get(i),vote);
                }
            }
            System.out.println("Jeff Probst: I'll read the votes");
            for(int i = 0; i< voteCnt.size();i++) {
                voteName  = voteCnt.get(i);
                System.out.println("One vote: " + voteName);
                votes.put(voteName,votes.getOrDefault(voteName,0)+1);
                System.out.println("Jeff Probst: That is " + votes.get(voteName) + " votes for " + voteName);
                if(votes.get(voteName)>max){
                    max = votes.get(voteName);
                }
                if(votes.get(voteName)==max){
                    votedOut.put(max,voteName);
                }
                votesLeft = votesLeft -1;
            }
        }
        if(votes.containsValue(max)){
            listOfKeys = new ArrayList<>();
            for(Map.Entry<Player,Integer> entry : votes.entrySet()){
                if(entry.getValue().equals(max)){
                    listOfKeys.add(entry.getKey());
                }
            }
        }
        if(listOfKeys.size()!=1){
            rocks(listOfKeys,losers);
        }else {
            tribes.get(0).getTribePlayers().get(numImmune).setImmune(false);
            System.out.println("Jeff Probst: That is enough votes, " + votedOut.get(max) + " please bring me your torch.");
            System.out.println("Jeff Probst: " + votedOut.get(max) + " the tribe has spoken");
            eliminated.add(votedOut.get(max));
            if(players.size()<12) {
                jury.add(votedOut.get(max));
            }
            Scores p = new Scores(votedOut.get(max).getScore(),votedOut.get(max),players.size());
            totals.add(p);
            players.remove(votedOut.get(max));
            tribes.get(lostTribe).getTribePlayers().remove(votedOut.get(max));
            System.out.println();
            System.out.println("Jeff Probst: Here is who voted for who: ");
            System.out.println(tribalCouncilVotes);
            System.out.println();
            voteAdd(losers,max);
        }
        tribalCouncilVotes.clear();
        Tribe b = new Tribe();
        b.setTribePlayers(tribes.get(lostTribe).getTribePlayers());
        b.setTribeName(tribes.get(lostTribe).getTribeName());
        tribes.set(lostTribe,b);
        losingTribe=b;
        day = day +3;
        System.out.println();
        System.out.println("-------------------------");
        System.out.println();
    }

    public void totals(){
        for(int i = 0; i< totals.size();i++){
            System.out.println(totals.get(i));
        }
    }

    public void tribeSwap(){
        ArrayList<Player> swap = new ArrayList<>();
        ArrayList<Player> function = new ArrayList<>();
        swap.addAll(players);
        System.out.println("Jeff Probst: Everybody drop your buffs, we are switching up tribes!");
        for(int i = 0; i<2;i++){
            ArrayList<Player> tribeMems = new ArrayList<>();
            for(int j = 0; j<players.size()/2;j++){
                int swapCnt = r.nextInt(swap.size());
                Player nextPlayer = swap.get(swapCnt);
                while(function.contains(nextPlayer)){
                    swapCnt = r.nextInt(swap.size());
                    nextPlayer = swap.get(swapCnt);
                }
                tribeMems.add(nextPlayer);
                function.add(nextPlayer);
                swap.remove(swapCnt);
            }
            Tribe a = new Tribe(tribes.get(i).tribeName(),tribeMems, 0);
            tribes.set(i,a);
            System.out.println("Jeff Probst: Here is the new " + tribes.get(i).tribeName() + " Tribe!");
            System.out.println(tribes.get(i).toString());
        }
        if(numTribes>2) {
            for (int i = 2; i < tribes.size(); i++) {
                tribes.remove(i);
                numTribes--;
                i--;
            }
        }
        System.out.println();
        System.out.println("-------------------------");
        System.out.println();
    }

    public void voteAdd(Tribe losers, int max){
        for(int i = 0; i<losers.getTribePlayers().size(); i++){
            if(tribalCouncilVotes.containsKey(losers.getTribePlayers().get(i))){
                if(tribalCouncilVotes.get(losers.getTribePlayers().get(i)).equals(votedOut.get(max))){
                    losers.getTribePlayers().get(i).setScore(losers.getTribePlayers().get(i).getScore()+1);
                }
            }
        }
    }

    public void rocks(List<Player> listOfKeys,Tribe losers){
            System.out.println("Jeff Probst: We have tied again, therefore we go to rocks!");
            votedOut.clear();
            for(int i = 0;i< listOfKeys.size();i++){
                if(listOfKeys.contains(losers.getTribePlayers().get(i))){
                    losers.getTribePlayers().get(i).setImmune(true);
                }
            }
            int rocks = losers.getTribePlayers().size();
            int whiteRock = r.nextInt(rocks);
            votedOut.put(whiteRock,losers.getTribePlayers().get(whiteRock));
            while(votedOut.get(whiteRock).equals(listOfKeys.get(0)) || votedOut.get(whiteRock).equals(listOfKeys.get(1)) || votedOut.get(whiteRock).equals(losers.getTribePlayers().get(numImmune))){
                whiteRock = r.nextInt(rocks);
                votedOut.put(whiteRock,losers.getTribePlayers().get(whiteRock));
            }
        System.out.println("Jeff Probst: " + votedOut.get(whiteRock) + ", you have drawn the white rock!");
        System.out.println("Jeff Probst: Please bring me your torch");
        System.out.println("Jeff Probst: The game has spoken");
        for(int i = 0; i<losers.getTribePlayers().size();i++){
            losers.getTribePlayers().get(i).setImmune(false);
        }
        eliminated.add(votedOut.get(whiteRock));
        if(players.size()<12) {
            jury.add(votedOut.get(whiteRock));
        }
        Scores p = new Scores(votedOut.get(whiteRock).getScore(),votedOut.get(whiteRock),players.size());
        totals.add(p);
        players.remove(votedOut.get(whiteRock));
        tribes.get(lostTribe).getTribePlayers().remove(votedOut.get(whiteRock));
    }

    public void finalTribal(){
        int votesForOne = 0;
        int votesForTwo = 0;
        System.out.println("Jeff Probst: Welcome to the Final Tribal Council!");
        System.out.println("Jeff Probst: You've made it the farthest anyone can go");
        System.out.println("Jeff Probst: Now you have to convince the jury that you voted out to vote for you to win the million dollars");
        System.out.println("Jeff Probst: Goodluck!");
        System.out.println();
        System.out.println("Jeff Probst: I'll Read The Votes");
        for(int i = 0;i< jury.size();i++){
            int finalVote = r.nextInt(tribes.get(0).getTribePlayers().get(0).getScore()+tribes.get(0).getTribePlayers().get(1).getScore());
            if(finalVote<tribes.get(0).getTribePlayers().get(0).getScore()){
                finalTribalVotes.put(jury.get(i),tribes.get(0).getTribePlayers().get(0));
                votesForOne++;
                System.out.println("Jeff Probst: That's "+ votesForOne + " votes for " + tribes.get(0).getTribePlayers().get(0));
            }
            else{
                finalTribalVotes.put(jury.get(i),tribes.get(0).getTribePlayers().get(1));
                votesForTwo++;
                System.out.println("Jeff Probst: That's "+ votesForTwo + " votes for " + tribes.get(0).getTribePlayers().get(1));
            }
        }
        if(votesForOne>votesForTwo){
            System.out.println("Jeff Probst: " + tribes.get(0).getTribePlayers().get(0) + " you are the SOLE SURVIVOR!");
            soleSurvivor = tribes.get(0).getTribePlayers().get(0);
            secondPlace = tribes.get(0).getTribePlayers().get(1);
        }else{
            System.out.println("Jeff Probst: " + tribes.get(0).getTribePlayers().get(1) + " you are the SOLE SURVIVOR!");
            soleSurvivor = tribes.get(0).getTribePlayers().get(1);
            secondPlace = tribes.get(0).getTribePlayers().get(0);
        }
        System.out.println();
        System.out.println("Finalist Scores: ");
        Scores p = new Scores(secondPlace.getScore(),secondPlace,2);
        totals.add(p);
        Scores d = new Scores(soleSurvivor.getScore(),soleSurvivor,1);
        totals.add(d);
        System.out.println(tribes.get(0).getTribePlayers().get(0) + " had " + tribes.get(0).getTribePlayers().get(0).getScore() + " points!");
        System.out.println(tribes.get(0).getTribePlayers().get(1) + " had " + tribes.get(0).getTribePlayers().get(1).getScore() + " points!");
        System.out.println();
        System.out.println("-------------------------");
        System.out.println();
    }

    public void finalTribalVotes(){
        System.out.println("Jeff Probst: Final Tribal Votes:");
        System.out.println(finalTribalVotes);
        System.out.println();
        System.out.println("-------------------------");
        System.out.println();
    }

    public void placements(){
        System.out.println("Sole Survivor: " + soleSurvivor);
        System.out.println("2: " + secondPlace);
        int j = 0;
        for(int i = eliminated.size();i>0;i--){
            j= eliminated.size()+3-i;
            System.out.println(j + ": " + eliminated.get(i-1));
        }
        System.out.println();
        System.out.println("-------------------------");
        System.out.println();
    }

    public void immunityWins(){
        System.out.println("Immunity Wins: ");
        System.out.println(immunityWins);
        System.out.println();
        System.out.println("-------------------------");
        System.out.println();
    }

}
