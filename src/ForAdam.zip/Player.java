public class Player {
    private String name;
    private boolean immune;
    private int immWins;
    private int score;

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isImmune() {
        return immune;
    }

    public void setImmune(boolean immune) {
        this.immune = immune;
    }

    public int getImmWins() {
        return immWins;
    }

    public void setImmWins(int immWins) {
        this.immWins = immWins;
    }

    public Player(String name, boolean immune, int immWins, int score) {
        this.name = name;
        this.immune = immune;
        this.immWins = immWins;
        this.score = score;
    }

    @Override
    public String toString() {
        return name;
    }

    public Player(){
    }
}
