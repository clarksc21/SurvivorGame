import java.util.ArrayList;

public class Tribe {
    private String tribeName;
    private ArrayList<Player> tribePlayers;
    private int boost;

    public String getTribeName() {
        return tribeName;
    }

    public void setTribeName(String tribeName) {
        this.tribeName = tribeName;
    }

    public ArrayList<Player> getTribePlayers() {
        return tribePlayers;
    }

    public void setTribePlayers(ArrayList<Player> tribePlayers) {
        this.tribePlayers = tribePlayers;
    }

    public int getBoost() {
        return boost;
    }

    public void setBoost(int boost) {
        this.boost = boost;
    }

    public Tribe(String tribeName, ArrayList<Player> tribePlayers, int boost) {
        this.tribeName = tribeName;
        this.tribePlayers = tribePlayers;
        this.boost = boost;
    }

    @Override
    public String toString() {
        return tribeName + ": " + tribePlayers.toString();
    }

    public String tribeName(){
        return tribeName;
    }

    public Tribe(){

    }
}
