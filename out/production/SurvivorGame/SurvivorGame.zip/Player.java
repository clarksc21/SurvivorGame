public class Player {
    private String name;
    private boolean immune;
    private int type;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isImmune() {
        return immune;
    }

    public void setImmune(boolean immune) {
        this.immune = immune;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public Player(String name, boolean immune, int type) {
        this.name = name;
        this.immune = immune;
        this.type = type;
    }

    @Override
    public String toString() {
        return name;
    }

    public Player(){
    }
}
